package com.rama.mongo.operation.document;

import java.util.Date;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "Student")
public class Student {
	@Id
	public ObjectId _id;
	
	private String name;
	private String rollNo;
	private String age;
	private Date joiningsDate;
	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Student(ObjectId _id, String name, String rollNo, String age,
			Date joiningsDate) {
		super();
		this._id = _id;
		this.name = name;
		this.rollNo = rollNo;
		this.age = age;
		this.joiningsDate = joiningsDate;
	}
	public ObjectId get_id() {
		return _id;
	}
	public void set_id(ObjectId _id) {
		this._id = _id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getRollNo() {
		return rollNo;
	}
	public void setRollNo(String rollNo) {
		this.rollNo = rollNo;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public Date getJoiningsDate() {
		return joiningsDate;
	}
	public void setJoiningsDate(Date joiningsDate) {
		this.joiningsDate = joiningsDate;
	}
	

}
