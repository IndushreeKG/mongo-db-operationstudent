package com.rama.mongo.operation.service;

import java.util.List;

import javax.validation.Valid;

import org.bson.types.ObjectId;

import com.rama.mongo.operation.document.Employee;
import com.rama.mongo.operation.document.Student;

public interface DataOperationService {
	Student createData(@Valid Student student);
	List<Student> readAllData();
	Student updateData(@Valid Student student);
	void deleteData(ObjectId employee);
}
